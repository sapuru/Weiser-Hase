/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abc;

import java.util.ArrayList;
import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author Rem
 */
public class Abc {

    public static void main(String[] args) {
        Abc abc = new Abc();
        abc.Anagrama();

    }

    public static String Anagrama() {
        Random aleatorio = new Random();
        String[] palabra = {"mitologia", "metodologia", "programacion"};
        String palabraActual = null;
        ArrayList entrada = new ArrayList();
        ArrayList salida = new ArrayList();
        for (int i = 0; i < palabra.length; i++) {
            Random ran = new Random();
            int a = ran.nextInt(1);
            palabraActual = palabra[a];
        }
        String palabraFinal = "";
        int cont = 0;
        int num = 0;
        while (true) {
            try {
                entrada.add(palabraActual.charAt(num));
                num++;
            } catch (IndexOutOfBoundsException err) {
                break;
            }
        }
        int tamano = entrada.size();
        while (salida.size() != tamano) {
            int numal = aleatorio.nextInt(entrada.size());
            salida.add(entrada.remove(numal));
        }
        for (Object l : salida) {
            palabraFinal += l;
        }
        do {
            String ana;
            System.out.println(ana=palabraFinal);            
//ana = JOptionPane.showInputDialog(palabraFinal);
            if (palabraActual.equals(ana)) {
                System.out.println("bien");
                //JOptionPane.showMessageDialog(null, "Perfecto");
                cont = 3;
            } else {
                System.out.println("mal");
                //JOptionPane.showMessageDialog(null, "Mal, Intente pensar mas, usted puede");
                cont++;
            }

        } while (cont != 3);
//        switch (cont) {        //Inicializamos el Switch para que ingrese al menu
//            case 3:
//                //Si el usuario ingreso mal los datos sale este mensaje
//                //JOptionPane.showMessageDialog(null, "Regrese dentro de las 24 horas\n"
//                        //+ "Por ingresar más de tres veces el usuario o contraseña incorrecta");
//                break;
//            
//            default:
//        }
        return Anagrama();
    }

}
